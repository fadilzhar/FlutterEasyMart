List<Map<String, String>> splashData = [
  {
    "text": "Hello There! Welcome to Easy Mart! \n Let's shop!",
    "image": "assets/images/splash_1.png"
  },
  {
    "text":
        "We help people connect with store \naround United State of America",
    "image": "assets/images/splash_2.png"
  },
  {
    "text": "We show the easy way to shop. \nJust stay at home with us",
    "image": "assets/images/splash_3.png"
  },
];
